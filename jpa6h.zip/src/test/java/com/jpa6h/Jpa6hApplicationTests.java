package com.jpa6h;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpa6hApplicationTests {

	@Test
	void contextLoads() {
	}

}
