package com.jpa6h.repository;

import com.jpa6h.entity.City;
import com.jpa6h.entity.District;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistrictRepository extends JpaRepository<District,Integer> {




}

