package com.jpa6h;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpa6hApplication {

	public static void main(String[] args) {
		SpringApplication.run(Jpa6hApplication.class, args);
	}

}
